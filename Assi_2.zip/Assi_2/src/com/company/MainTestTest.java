package com.company;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class MainTestTest {

    @Test
    void nonRepeated() {
        assertEquals(20,Main.nonRepeated(new int[]{1,18,20,1,14,16,18,9,0},9));
    }
}