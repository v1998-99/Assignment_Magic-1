package com.company;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        // write your code here
        Scanner sc = new Scanner(System.in);
        //int n = sc.nextInt();
        int arr[] = new int[9];
        int n=arr.length;

        for (int i = 0; i < n; i++) {
            arr[i] = sc.nextInt();
        }
        System.out.print("Array are:");
        for (int i = 0; i < n; i++){
            System.out.print(arr[i]+" ,");
        }
        System.out.println();
        System.out.println("First Non Repeated is " + nonRepeated(arr,n));
    }


    public static int nonRepeated(int arr[],int n)
    {
        //int res = 0;
        int i=0;
        for (i = 0; i < n; i++) {
            int j;
            for (j = 0; j < n; j++) {
                if (i != j && arr[i] == arr[j]) {
                    break;
                }
            }
            if (j == n) {
                return arr[i];
            }
        }

        return -1;
    }
}
//1 , 18, 20, 1 , 14 , 16 , 18 , 9 , 0
