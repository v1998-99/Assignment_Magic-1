package com.company;

import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    private String value;

    public Main(String val) { this.value = val; }

    // Defining a getter method
    public String getValue() { return this.value; }

    // list of Main objects
    static ArrayList<Main> list = new ArrayList<>();
//    public static void sortList(int length)
//    {
//        // Sorting the list using lambda function
//        list.sort(
//                (a, b) -> a.getValue().compareTo(b.getValue()));
//        System.out.println("Sorted List : ");
//
//        // Printing the sorted List
//        for (Main obj : list) {
//            System.out.println(obj.getValue());
//        }
//    }

    public static void main(String[] args) {
	// write your code here
        Scanner sc = new Scanner(System.in);
        System.out.print(
                "How many characters you want to enter : ");
        int l = sc.nextInt();

        // Taking value of list as input
        for (int i = 0; i < l; i++) {
            list.add(new Main(sc.next()));
        }

        sortList();
    }

    private static void sortList() {
        // Sorting the list using lambda function
        list.sort(
                (a, b) -> a.getValue().compareTo(b.getValue()));
        System.out.println("Sorted List : ");

        // Printing the sorted List
        for (Main obj : list) {
            System.out.println(obj.getValue());
        }
    }

}
