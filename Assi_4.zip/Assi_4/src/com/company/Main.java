package com.company;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
	Scanner sc= new Scanner(System.in);
	int arr[]= new int[9];
	int n= arr.length;
	for(int i=0;i<n;i++)
	{
	    arr[i]=sc.nextInt();
    }
        System.out.print("Array are :");
	for(int i=0;i<n;i++){
        System.out.print(arr[i]+" , ");

    }
        System.out.println();
        System.out.println("Second Largest : "+secondLargestElement(arr,n));


    }
    public static int secondLargestElement(int arr[],int n){
        int i, first, second;

        /* There should be atleast two elements */
        if ( n< 2) {

            return -1;
        }

        first = second = Integer.MIN_VALUE;
        for (i = 0; i < n; i++) {
            if (arr[i] > first) {
                second = first;
                first = arr[i];
            }

            else if (arr[i] > second && arr[i] != first)
                second = arr[i];
        }

        if (second == Integer.MIN_VALUE)
            return -1;
        else
            return second;
    }

    }

//1 , 18, 20, 1 , 14 , 16 , 18 , 9 , 0