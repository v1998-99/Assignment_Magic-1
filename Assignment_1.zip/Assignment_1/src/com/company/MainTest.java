package com.company;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;
import static org.junit.jupiter.api.Assertions.assertEquals;

class MainTest {

    @Test
    public void main() {

        assertEquals( new int[]{'a',2, 'j' ,1, 'v' ,1},Main.countChar(new String("java")));
    }
}