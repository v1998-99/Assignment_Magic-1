package com.company;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String s = sc.nextLine();
        s=s.toLowerCase();
        System.out.println(countChar(s));

    }

    public static Map<Character, Integer> countChar(String s) {
        Map<Character, Integer> map = new HashMap<>();
        int[] freq = new int[s.length()];
        char s_arr[] = s.toCharArray();
        //System.out.println("Characters and their corresponding frequencies");


        for (int i = 0; i < s_arr.length; i++) {
            //int c=0;
            freq[i] = 1;
            for (int j = i + 1; j < s_arr.length; j++) {
                if (s_arr[i] == s_arr[j]) {
                    freq[i]++;
                    s_arr[j] = '0';

                }

            }
        }

        System.out.println("Characters and their corresponding frequencies");
        for (int i = 0; i < freq.length; i++) {
            if (s_arr[i] != ' ' && s_arr[i] != '0')
                //System.out.print(s_arr[i] + "-"+ freq[i]+",");
                map.put(s_arr[i],freq[i]);
        }
        return map;
    }

}
